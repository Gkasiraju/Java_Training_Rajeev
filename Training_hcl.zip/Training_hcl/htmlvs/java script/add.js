var cal=function(a,b,calback){
    return calback(a,b);
}
var add=function(a,b){
    return a+b;
}
console.log(add(2,4,add));